package MergeSort;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MergeSorter implements Callable<List<Integer>> {
    List<Integer> toBeSorted;
    ExecutorService executorService;
    MergeSorter(List<Integer> list,ExecutorService executorService){
        this.toBeSorted = list;
        this.executorService = executorService;
    }

    @Override
    public List<Integer> call() throws Exception {
        // TODO Auto-generated method stub
        if(toBeSorted.size() <=1) {
            return toBeSorted;
        }

        int mid = toBeSorted.size()/2;

        //Left 0 to mid-1
        //Right mid to size
        List<Integer> leftIntegers = new ArrayList<>();

        for(int i=0;i<mid;i++) {
            leftIntegers.add(toBeSorted.get(i));
        }

        List<Integer> rightIntegers = new ArrayList<>();

        for(int i=mid;i<toBeSorted.size();i++) {
            rightIntegers.add(toBeSorted.get(i));
        }
        
        MergeSorter mergeSorterLeft = new MergeSorter(leftIntegers,executorService);
        MergeSorter mergeSorterRight = new MergeSorter(rightIntegers,executorService);

        Future<List<Integer>> futureLeft = executorService.submit(mergeSorterLeft);
        Future<List<Integer>> futureRight = executorService.submit(mergeSorterRight);


        List<Integer> leftSorted = futureLeft.get();
        List<Integer> rightSorted = futureRight.get();

        ///MERGE
        List<Integer> sorted = new ArrayList<Integer>();
        
        int i = 0;
        int j = 0;

        while(i<leftSorted.size() && j <rightSorted.size()) {
            if(leftSorted.get(i) < rightSorted.get(j)) {
                sorted.add(leftSorted.get(i));
                i++;
            } else {
                sorted.add(rightSorted.get(j));
                j++;
            }
        } 

        while(i<leftSorted.size()) {
            sorted.add(leftSorted.get(i));
            i++;
        }

        while(j<rightSorted.size()) {
            sorted.add(rightSorted.get(j));
            j++;
        }

        return sorted;
    }
    
}

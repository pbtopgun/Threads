package MergeSort;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Client {
    public static void main(String a[]) throws Exception{
        System.out.println("Merge Sort");
        List<Integer> input = List.of(1,2,9,7,5,3,8);

        ExecutorService executorService = Executors.newFixedThreadPool(11);

        MergeSorter mergeSorter = new MergeSorter(input,executorService);
        Future<List<Integer>> future = executorService.submit(mergeSorter);

        List<Integer> output = future.get();
        System.out.println(output);

        //executorService.shutdown();
    }
}

package HelloWorldPrinter;
public class HelloWorldPrinter implements Runnable{

    @Override
    public void run() {
        System.out.println("Hello World from HelloWorldPrinter Task" + " printed from thread:"
        + Thread.currentThread().getName());
    }
    
}

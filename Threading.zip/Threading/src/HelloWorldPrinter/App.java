package HelloWorldPrinter;
public class App {

    public static void main(String[] args) throws Exception {
       System.out.println("Hello World From"+" "+Thread.currentThread().getName()); 

       HelloWorldPrinter hwp = new HelloWorldPrinter();
       Thread t = new Thread(hwp);
       t.start();  //Thread-0 for whatever work of Hello WorldPrinter in run() method
       //t.run(); 
       

       Thread t1 = new Thread(hwp);
       t1.start();  //Thread-0 for whatever work of Hello WorldPrinter in run() method

       doPrint(); // main Thread
    }

    private static void doPrint(){
        System.out.println("Hello Class From"+" "+Thread.currentThread().getName()); 
    }
}

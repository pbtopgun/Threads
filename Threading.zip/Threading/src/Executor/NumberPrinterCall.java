package Executor;

import java.util.concurrent.Callable;

public class NumberPrinterCall implements Callable<String> {
    int numToPrint;
    NumberPrinterCall(int num) {
        this.numToPrint = num;
    }

    @Override
    public String call() throws Exception {
        String s = numToPrint + " " + Thread.currentThread().getName();
        System.out.println(s);    
        return s;
    }

}

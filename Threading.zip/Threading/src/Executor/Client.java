package Executor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Client {
    public static void main(String[] args) throws Exception {
        System.out.println("Executor");

        ExecutorService executorService = Executors.newFixedThreadPool(10); 
        //ExecutorService executorServiceViswa = Executors.newFixedThreadPool(15);

        //ExecutorService executorSinglExecutors = Executors.newSingleThreadExecutor();
        
        /**for(int i=0;i<=10000;i++) {
            NumberPrinter np = new NumberPrinter(i);
            //executorSinglExecutors.submit(np);
            executorService.submit(np);
        }
        executorService.shutdown();
        **/


        ExecutorService executorServiceForCall = Executors.newFixedThreadPool(10);  //New Thread pool for callable
        List<Future<String>> futureOutputs = new ArrayList<Future<String>>();

        for(int i=0;i<=100;i++) {
            NumberPrinterCall np = new NumberPrinterCall(i);
            Future<String> future = executorServiceForCall.submit(np);
            //String output = future.get(); // this is the output from the task "np"  //Blocking call
            //System.out.println("FROM MAIN:"+output);
            futureOutputs.add(future);
        }
        
        //printing
        for(int o=0;o<futureOutputs.size();o++) {
            Future<String> future = futureOutputs.get(o); // this is the output from the task "np"  //Blocking call
            String output = future.get();
            System.out.println("FROM MAIN:"+output);
        }

        executorServiceForCall.shutdown();

    }
}



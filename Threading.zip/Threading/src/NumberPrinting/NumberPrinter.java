package NumberPrinting;

public class NumberPrinter implements Runnable{
    int numToPrint;

    NumberPrinter(int num) {
        this.numToPrint = num;
    }

    @Override
    public void run() {
        System.out.println(numToPrint + " " + Thread.currentThread().getName());    
    }
}
